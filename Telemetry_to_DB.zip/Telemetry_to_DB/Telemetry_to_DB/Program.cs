﻿using Microsoft.Azure.Cosmos;
using Newtonsoft.Json;

public class Program
{
    public static async Task Main(string[] args)
    {
        // New instance of CosmosClient class using a connection string
        using CosmosClient client = new CosmosClient(
            connectionString: "AccountEndpoint=https://servicecosmosdb.documents.azure.com:443/;AccountKey=8cGksnNqTPVgWPBgFtNuamm2MIChlrUAvyAhMC1C0q9Djo4jBumpf6zTLIjNhWAuLcPn1pXShI1bACDbAxVQjg==;"
        );

        Database database = client.GetDatabase("Database");
        Container container = database.GetContainer("Container");

        System.Diagnostics.Process process = new System.Diagnostics.Process();
        System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo
        {
            WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden,
            FileName = "cmd.exe",
            Arguments = @"/C scp -o ProxyCommand=""ssh guests@172.26.225.3 nc 10.42.0.160 22"" rpiApple@10.42.0.160:~/Sending_telemetry/data.json /Users/%USERNAME%"
        };
        process.StartInfo = startInfo;
        Thread.Sleep(2000);

        while (true){
        // Read JSON from the file
            process.Start();
            Console.WriteLine("Data downloaded successfuly");
            try
            {
                var jsonLines = File.ReadAllLines($"C:\\Users\\{Environment.UserName}\\data.json");

                foreach (var line in jsonLines)
                {
                    try
                    {
                        var item = JsonConvert.DeserializeObject<Item>(line);

                        if (item != null)
                        {
                            // Perform operations with the deserialized item
                            // Example: Uploading item to Cosmos DB
                            await container.UpsertItemAsync(item);
                            Console.WriteLine($"Item uploaded: {JsonConvert.SerializeObject(item)}");
                        }
                    }
                    catch (JsonException jsonEx)
                    {
                        Console.WriteLine($"Error deserializing JSON: {jsonEx.Message}");
                    }

                    Thread.Sleep(10000);
                }
            }
            catch (IOException){}
        }
    }

    public class Item
    {
        [JsonProperty(PropertyName = "id")]
        public required string id { get; set; }

        [JsonProperty(PropertyName = "temperature")]
        public required string Temperature { get; set; }

        [JsonProperty(PropertyName = "pointInfo")]
        public required string PointInfo { get; set; }

        [JsonProperty(PropertyName = "creationTime")]
        public required string CreationTime { get; set; }
    }
}
